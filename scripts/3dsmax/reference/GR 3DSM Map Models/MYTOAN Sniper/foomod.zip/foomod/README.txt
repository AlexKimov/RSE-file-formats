foomod.zip - includes needed files for playing map "MYTOAN Sniper",
             also includes unlit map and lighting solution which
             can be loaded in to LightingTool

* INCLUDED IN THIS RELEASE YOU HAVE JUST DOWNLOADED *
[mytoan_cm_fix.zip - Almost working command map, original is less useful.]
[                    Because of stupid command map system in Ghost Recon ]
[                    it is impossible to get "full screen" command map	 ]
[                    in small maps, with this cm it is possible to guide ]
[                    AI and see your own position on command map though	 ]
** Fix by Meprolite ** Thanks

* SUPPORT FOR ALL GAME TYPES (HAMBURGER HILL, SIEGE, SAR, DOMINATION, RECON, FIREFIGHT, MISSION, ...) *
[ http://www.macgamingmods.com/modules.php?op=modload&name=Downloads&file=index&req=viewdownloaddetails&lid=263&ttitle=Mytoan_Sniper ]
** Fix by Monoman ** Thank you very much

foomod_level_MAX5.zip - includes MAX5 scene, textures are in
                        foomod.zip (doesn't work with previous
                        versions of MAX)

You may freely modify and distribute the level and so on. Just
give the credit whom it belongs to.

What you may not do, is: use any parts of the scene in your
animations / pictures / anything non-related with the modding scene
of Ghost Recon.

INSTALL
Unzip in to Ghost Recon's mod-folder (...\Ghost Recon\Mods\ -folder)
and activate mod under Ghost Recon's options/mods tab.

Quick mission -> MYTOAN Sniper -> play
Doesn't support any other multiplayer mode than "team mission",
would you like to fix this (siege, and so on would be nice)?-)


(c)k1ller
http://sektori.com/~pege/
pege@sektori.com
(link to this file if you make your own mods / missions / so on)
(prefer address http://sektori.com/~pege/gr/)